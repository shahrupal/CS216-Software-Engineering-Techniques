//Course: CS216-001
//Project: Lab Assignment 7
//Date: 03/08/2017
//Purpose: given an expression, be able to output whether the parentheses in the expression are matched or unmatched
//         if there is a bound error (push overflows stack or pop underflows stack), output this to the user
//Author: Rupal Shah

//add appropriate headers
#include <iostream>
#include "stack.h"
using namespace std;

//push an item on the top of the stack
void stack::push(char item) throw(bound_err){
    //if the amount of positions in the stack are less than the max capacity
    if(top_index<STACK_SIZE-1){
        //add given item to stack
        data[top_index+1]=item;
        top_index=top_index+1;
    }
    else{
        //otherwise, output error message,
        //letting user know the stack is overflowed due to surpassing max capacity
        bound_err what("Push overflows stack");
        throw what;
    }
}

//pop sn item from the top of the stack
char stack::pop() throw(bound_err){
    char popitem;
    //if the stack is not empty
    if(top_index>=0){
        //pop last item from the stack
        popitem=data[top_index];
        top_index=top_index-1;
        return popitem;
    }
    else{
        //otherwise, output error message,
        //letting user know that the stack is underflowed due to attempting to delete a nonexistent item
        bound_err what("Pop underflows stack");
        throw what;
    }
}

//check if stack is empty
bool stack::isEmpty() const{
    if(top_index<0){
        return true;
    }
    else{
        return false;
    }
}

//check if stack is full (reaches max size of stack)
//max size is defined by constant STACK_SIZE
bool stack::isFull() const{
    if(top_index==STACK_SIZE){
        return true;
    }
    else{
        return false;
    }
}
