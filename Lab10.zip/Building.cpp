/* Course: CS216-002
 * Name: Rupal Shah
 * Date: 04/05/2017 
 * Purpose: To create the functions defined in the Building class
 *          Allow to get parameters of Building
 *          Allow to compare Building names and ID lexicographically
 *          Allow to compare Building coordinates reverse lexicographically
 *          Output Building information via overload operator
 */

#include <iostream>
#include <string>
#include <stdio.h>
#include <string.h>
#include "Building.h"
#include "BuildingList.h"
using namespace std;

//default constructor
Building::Building(){
    name = "";
    ID = "";
    coordinate = "";
}

//constructor
Building::Building(string name, string id, string position){
    this->name = name;
    ID = id;
    coordinate = position;
}

//return name of Building
string Building::get_Name() const{
    return name;
}

//return ID of Building
string Building::get_ID() const{
    return ID;
}

//return coordinate/position of Building
string Building::get_Coordinate() const{
    return coordinate;
}

//compare two Building names lexicographically
//if B1 comes before B2, return 1
//if B1 comes after B2, return -1
//if B1 and B2 are equal, return 0
int Building::compareByName(Building B1, Building B2){
    string b1name = B1.get_Name();
    string b2name = B2.get_Name();
    
    if(strcmp(b1name.c_str(),b2name.c_str()) < 0){
        return 1;
    }
    else if(strcmp(b1name.c_str(),b2name.c_str()) > 0){
        return -1;
    }
    else{
        return 0;
    }
}

//compare two Building IDs lexicographically
//if B1 comes before B2, return 1
//if B1 comes after B2, return -1
//if B1 and B2 are equal, return 0
int Building::compareByID(Building B1, Building B2){
    string b1id = B1.get_ID();
    string b2id = B2.get_ID();

    if(strcmp(b1id.c_str(),b2id.c_str()) < 0){
        return 1;
    }
    else if(strcmp(b1id.c_str(),b2id.c_str()) > 0){
        return -1;
    }
    else{
        return 0;
    }

}

//compare two Building coordinates/positions REVERSE lexicographically
//if B1 comes before B2, return -1
//if B1 comes after B2, return 1
//if B1 and B2 are equal, return 0
int Building::compareByReverseCoordinate(Building B1, Building B2){
    string b1coord = B1.get_Coordinate();
    string b2coord = B2.get_Coordinate();

    if(strcmp(b1coord.c_str(),b2coord.c_str()) < 0){
        return -1;
    }
    else if(strcmp(b1coord.c_str(),b2coord.c_str()) > 0){
        return 1;
    }
    else{
        return 0;
    }
}

//use overload operator to output Builidng information in correct format
ostream &operator<<(ostream &out, const Building &B){
    out << B.get_Name() << "\t" << "(ID: " <<  B.get_ID() << ")" << " ---> " << B.get_Coordinate();
    return out;
}
    
