/*
 * converter.cpp
 * provides implementation of functions declared in convert.h
 */
#include <string>
#include <iostream>
#include "converter.h"
#include "stack.h"

bool isOperand(char op)
{
    if (op == '+' || op == '-' || op == '*' || op == '/' || op == '(' || op == ')')
        return false;
    return true;
}

int precedence(char op)
{
    if (op == '*' || op == '/')
        return HIGHPRECEDENCE;
    if (op == '+' || op == '-')
        return LOWPRECEDENCE;
    return -1;
}

string infix_to_postfix(string Ei)
{
    stack operators;
    string postfix = "";
    char temp = ' ';
    

    for(int i=0; i<Ei.length(); i++){ 

        if(Ei[i]=='('){
            operators.push(Ei[i]);
        }

        else if (Ei[i]==')'){
        
            temp=operators.pop();
            operators.push(temp);

            while(!operators.isEmpty() && (temp!='(')){
                postfix=postfix+temp;
                operators.pop();
                if(!operators.isEmpty()){
                    temp=operators.pop();
                    operators.push(temp);
                }
            }
            if(!operators.isEmpty()){
                operators.pop();
            }
        }

        else if(isOperand(Ei[i])==false){
            if(!operators.isEmpty()){
                temp=operators.pop();
                operators.push(temp);
                
                bool isparenthesis = false;
                if(temp=='(' || temp==')' || Ei[i]=='(' || Ei[i]==')'){
                    isparenthesis=true;
                }

                while(!operators.isEmpty() && (precedence(temp)>=precedence(Ei[i])) && (isparenthesis==false) ){
                    postfix = postfix+temp;
                    operators.pop();
                    if(!operators.isEmpty()){
                        temp=operators.pop();
                        operators.push(temp);
                    }
                } 
            }
            operators.push(Ei[i]);
        }

        else if(isOperand(Ei[i])==true){
            postfix=postfix+Ei[i];
        }
    }

    while(!operators.isEmpty()){

        temp=operators.pop();
        operators.push(temp);
        
        postfix=postfix+temp;
        operators.pop();
    }

    return postfix;
}

bool valid_parentheses(string E)
{
    stack S;
    for(int i = 0; i < E.length(); i++)
    {
        if (E[i] == '(')
            S.push(E[i]);
        if (E[i] == ')')
            S.pop();
    }   
    return S.isEmpty();
}
