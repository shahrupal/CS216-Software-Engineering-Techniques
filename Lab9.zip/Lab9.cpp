//course: CS216-00x
//Project: Lab Assignment 9
//Date: 03/28/2017
//Assumption: read the sequence of terms from an input file, with the following format for each term:
//            weight(long integer)    query(string)
//            the data from the file has been sorted in lexicographical order by query
//Purpose: ask the user to type a key to match
//         use the binary search algorithm to find a matched term from the sequence of terms reading from the input file
//         a matched term is defined as the one which contains exactly the user-input key as the prefix
//         It also calculates the time spending on searching operation.    
//Author: (your name)

#include <iostream>
#include <fstream>
#include <string>
#include <ctime>
#include "term.h"
#include "autocomplete.h"

using namespace std;

int main(int argc, char** argv) 
{
    const int ARGUMENTS = 2;
    
    if (argc != ARGUMENTS)
    {
        cout << "Usage: " << argv[0] << " <filename>" << endl;
        return 1;
    }    
    
    ifstream infile;
    infile.open(argv[1]);
    if (!infile.good())
    {
        cout << "Cannot open the file named " << argv[1] << endl;
        return 2;
    }  
    
    Autocomplete autocomplete;
    long weight;
    string query;

    // read in the terms from the input file    
    while (infile >> weight)
    {
        infile >> ws;  // extract and ignore the blank space
        getline(infile, query);
        Term newterm(query, weight);
        autocomplete.insert(newterm);    
    } 
    infile.close();

    string prefix;
    cout << "Please input the search query(type \"exit\" to quit): " << endl;
    getline(cin, prefix);
    while (prefix != "exit")
    {
        clock_t tstart, tstop;
        tstart = clock();
        autocomplete.allMatches(prefix);
        tstop = clock();
        double  elapsed = (double)(tstop-tstart)/CLOCKS_PER_SEC;
        cout << "Time for searching one prefix-matched term: "<<  elapsed << " seconds." << endl;
        cout << "Please input the search query(type \"exit\" to quit): " << endl;
        getline(cin, prefix);
    }    
    return 0;
}

