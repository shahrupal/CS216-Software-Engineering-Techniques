#include <iostream>
#include <string>
#include "term.h"
using namespace std;

//default constructor
Term::Term(){
    query = "";
    weight = 0;
}

//initializes a term with the given query string and weight
Term::Term(string query, long weight){
    this->query = query;
    this->weight = weight;
}

//compares the two terms in descending order by weight
int Term::byReverseWeightOrder(Term that){
 if(this->weight < that.weight){
    return 1;
 }
 else if(this->weight > that.weight){
    return -1;
 }
 else{
    return 0;
 }
}

//compares the two terms in lexicographic order
//but using only the first r characters of each query
int Term::byPrefixOrder(Term that, int r){
    if(this->query.substr(0,r) < that.query.substr(0,r)){
        return 1;
    }
    else if(this->query.substr(0,r) > that.query.substr(0,r)){
        return -1;
    }
    else{
        return 0;
    }
}

//displays the term in the followingn format:
//the weight, followed by a tab key, followed by the query
void Term::print(){
    cout << weight << "\t" << query << endl;
}
