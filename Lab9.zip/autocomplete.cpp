/* 
 * File:   autocomplete.cpp
 * It provides the implementation of member functions of the Autocomplete class
 *
 * Author: pike
 *
 * Created on March 23, 2017
 */
#include <iostream>
#include "autocomplete.h"
#include "term.h"
#include <string>


using namespace std;

// default constructor
Autocomplete::Autocomplete()
{    
}

// inserts the newterm to the end of the vector   
void Autocomplete::insert(Term newterm)
{
    terms.push_back(newterm);
}

// Calling binary_searchHelper function to find one term with the query starting with key
// From the matched term in the vector, going forward and backward to find the firstIndex and lastIndex
// firstIndex: the index of the first query that equals the search key, or -1 if no such key
// lastIndex: the index of the last query that equals the search key, or -1 if no such key
void Autocomplete::Search(string key, int& firstIndex, int& lastIndex)
{
    //first index of key found
    //-1 if no match
    int keyindex = binary_searchHelper(terms, key, firstIndex, lastIndex);
    
    int templast = keyindex;
    int last = keyindex;
    int tempfirst = keyindex;
    int first = keyindex;

    while(last != -1){
        //new match will be new last boundary - do this until you cannot find another match
        //last will then be the first found index of key
        last = binary_searchHelper(terms, key, firstIndex, last-1);
            if(last == -1){
                break;
            }
        tempfirst = last;
    }
    
    while(first != -1){
        //new match will be new first boundary - do this until you cannot find another match
        //first will then be the last found index of key
        first = binary_searchHelper(terms, key, first+1, lastIndex);
            if(first == -1){
                break;
            }
        templast = first;
    }

    if(keyindex == -1){
        firstIndex = -1;
        lastIndex = -1;
        cout << "no match found! please try again.";
    }
    else{
        //update parameters, so you can use in allmatches function
        //parameters are addresses so they will automatically change
        //allmatches variables DO NOT have to be same as this function's variables
        firstIndex = tempfirst;
        lastIndex = templast;
    }
}

// recursive helper function for binary search
// returns the index number of one matched term
int Autocomplete::binary_searchHelper(vector<Term> terms, string key, int left_index, int right_index)
{
    if(right_index < left_index)
    {
        const int KEY_NOT_FOUND = -1;
        return KEY_NOT_FOUND;
    }
    else
    {
        Term keyterm(key, 0);
        int r = key.length();
        int middle = (left_index + right_index) / 2;
        if(keyterm.byPrefixOrder(terms[middle],r) > 0)
        {
            return binary_searchHelper(terms, key, left_index, middle - 1);
              
        }
        else if(keyterm.byPrefixOrder(terms[middle],r)  < 0)
        {
            return binary_searchHelper(terms, key, middle + 1, right_index);
        }
        else
        {
            return middle;
        }
    }
    
}

// print all the terms which start with the given prefix, in its original order(lexicographical order of the query)
void Autocomplete::allMatches(string prefix)
{
    int firstIndex = 0;
    int lastIndex = terms.size()-1;
   
    Search(prefix, firstIndex, lastIndex);
    
    if(firstIndex == -1 && lastIndex == -1){
        cout<<endl;
    }
    else{
        //all terms with indeces between first and last are matching (since in alphabetical order)
        //so print all of those in for loop
        for(int i = firstIndex; i <= lastIndex; i++){
            terms[i].print();
        }
    }
}    

// display all the terms    
void Autocomplete::print()
{
    for (int i = 0; i < terms.size(); i++)
        terms[i].print();
}
